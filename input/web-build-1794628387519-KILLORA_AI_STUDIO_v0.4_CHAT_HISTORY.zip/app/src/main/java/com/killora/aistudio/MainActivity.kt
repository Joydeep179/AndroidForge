package com.killora.aistudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF171B2A)
private val Purple = Color(0xFF8B5CF6)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { StudioPrefs(applicationContext) }
    private val api by lazy { AiApi() }
    private var workspace by mutableStateOf<Uri?>(null)
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            workspace = uri
            lifecycleScope.launch { prefs.saveFolder(uri.toString()) }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { workspace = prefs.folder()?.let(Uri::parse) }
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
            StudioScreen(prefs, api, workspace, workspace?.lastPathSegment ?: "No folder selected", { picker.launch(null) }, contentResolver, this)
        } }
    }
}

private fun riskReason(op: FileOperation): String? {
    if (op.action.equals("terminal", true)) {
        val c = op.command.lowercase()
        val dangerous = listOf(Regex("(^|[;&| ]+)rm\\s+(-[^ ]*\\s+)*(-r|-rf|-fr|--recursive)"), Regex("(^|[;&| ]+)sudo\\b"), Regex("(^|[;&| ]+)su\\b"), Regex("mkfs|\\bdd\\s+if=|wipefs|fdisk|parted"), Regex("git\\s+reset\\s+--hard|git\\s+clean\\s+-[a-z]*f"), Regex("curl[^\\n]*\\|\\s*(sh|bash)|wget[^\\n]*\\|\\s*(sh|bash)"), Regex("shutdown|reboot|poweroff"), Regex("chmod\\s+-r|chown\\s+-r"), Regex("(cat|less|more|head|tail)\\s+[^ ]*(\\.ssh|credentials|secrets|token|passwd)"))
        if (dangerous.any { it.containsMatchIn(c) }) return "This command may delete data, change system permissions, or expose sensitive files. Review it before running."
    }
    return null
}

@Composable
private fun StudioScreen(prefs: StudioPrefs, api: AiApi, workspace: Uri?, folder: String, pickFolder: () -> Unit,
                         resolver: android.content.ContentResolver, activity: ComponentActivity) {
    val scope = rememberCoroutineScope()
    var baseUrl by remember { mutableStateOf("") }; var key by remember { mutableStateOf("") }; var model by remember { mutableStateOf("") }
    var models by remember { mutableStateOf(listOf<String>()) }; var termuxPath by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }; var status by remember { mutableStateOf("Connect an API in Settings to start.") }
    var busy by remember { mutableStateOf(false) }; var showSettings by remember { mutableStateOf(false) }; var showHistory by remember { mutableStateOf(false) }
    var conversations by remember { mutableStateOf(listOf<ChatConversation>()) }
    var activeId by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf(ChatMessage("assistant", "Hi! I'm KILLORA AI STUDIO. Tell me what you want to build or fix."))) }
    var task by remember { mutableStateOf("") }; var agentHistory by remember { mutableStateOf(listOf<String>()) }
    var pendingOps by remember { mutableStateOf<List<FileOperation>>(emptyList()) }; var pendingIndex by remember { mutableIntStateOf(0) }
    var pendingRisk by remember { mutableStateOf("") }; var overwriteOp by remember { mutableStateOf<FileOperation?>(null) }
    var agentStep by remember { mutableIntStateOf(0) }; var buildRepairAttempts by remember { mutableIntStateOf(0) }; var repairLimitReached by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        baseUrl = prefs.baseUrl() ?: ""; key = prefs.apiKey() ?: ""; model = prefs.model() ?: ""; termuxPath = prefs.termuxPath() ?: ""
        conversations = prefs.conversations()
        val wanted = prefs.activeConversationId()
        val active = conversations.firstOrNull { it.id == wanted } ?: conversations.firstOrNull()
        if (active != null) { activeId = active.id; chat = active.messages }
        else { val c = ChatConversation(title = "New chat", messages = chat); activeId = c.id; conversations = listOf(c); prefs.saveActiveConversation(c.id) }
    }
    LaunchedEffect(chat, activeId) {
        if (activeId.isNotBlank()) {
            val old = conversations.filterNot { it.id == activeId }
            val title = chat.firstOrNull { it.role == "user" }?.text?.take(42) ?: "New chat"
            val updated = ChatConversation(activeId, title, chat, System.currentTimeMillis())
            conversations = (listOf(updated) + old).take(80)
            prefs.saveConversations(conversations)
        }
    }
    fun addMessage(role: String, text: String) { chat = chat + ChatMessage(role, text) }
    fun newConversation() {
        val c = ChatConversation(title = "New chat", messages = listOf(ChatMessage("assistant", "Hi! What are we building today?")))
        activeId = c.id; chat = c.messages; agentHistory = emptyList(); task = ""; pendingOps = emptyList(); pendingIndex = 0
        scope.launch { prefs.saveActiveConversation(c.id) }
        showHistory = false
    }
    fun openConversation(c: ChatConversation) {
        activeId = c.id; chat = c.messages; agentHistory = emptyList(); task = ""; pendingOps = emptyList(); pendingIndex = 0
        scope.launch { prefs.saveActiveConversation(c.id) }; showHistory = false
    }

    suspend fun execute(op: FileOperation) {
        val result = withContext(Dispatchers.IO) { Workspace.execute(op, workspace, resolver, TermuxBridge(activity, termuxPath)) }
        agentHistory = agentHistory + "ACTION ${op.action} ${op.path.ifBlank { op.command }}\nRESULT $result"
        addMessage("assistant", result)
        if (op.action.equals("terminal", true)) {
            val report = BuildDiagnostics.inspect(op.command, result)
            if (report.isBuildCommand) {
                addMessage("assistant", "Build check: ${report.summary}")
                agentHistory = agentHistory + "BUILD_DIAGNOSTIC: ${report.summary}\n${report.relevantLines}"
                if (report.failed) {
                    buildRepairAttempts++
                    if (buildRepairAttempts < 3) task += "\n\nBUILD SELF-REPAIR: inspect actual error logs, make the smallest fix, then rerun the same build command. Attempt $buildRepairAttempts of 3."
                    else { repairLimitReached = true; status = "Build repair limit reached. Review logs." }
                } else if (report.exitCode == 0) { buildRepairAttempts = 0; status = "Build succeeded (exit code 0)." }
            }
        }
    }
    suspend fun continueAgent() {
        if (repairLimitReached || agentStep >= 12) { busy = false; status = "Agent paused. Review the conversation and continue when ready."; return }
        agentStep++
        val cfg = ApiConfig(baseUrl, key, model)
        val plan = withContext(Dispatchers.IO) { api.nextAgentStep(cfg, task, agentHistory, chat) }
        addMessage("assistant", plan.summary)
        if (plan.done || plan.operations.isEmpty()) { addMessage("assistant", "Task complete. Check your workspace for the result."); busy = false; status = "Ready"; return }
        for ((idx, op) in plan.operations.withIndex()) {
            val danger = riskReason(op)
            val exists = if (op.action.equals("write", true)) withContext(Dispatchers.IO) { runCatching { Workspace.read(op.path, workspace, resolver); true }.getOrDefault(false) } else false
            if (danger != null || exists) {
                pendingRisk = danger ?: "This file already exists. Replacing it will overwrite its current contents."
                pendingOps = plan.operations.drop(idx); pendingIndex = 0; busy = false; status = "Review this potentially risky action."; return
            }
            execute(op)
        }
        continueAgent()
    }
    suspend fun processPending() {
        while (pendingOps.isNotEmpty()) {
            val op = pendingOps.first()
            val danger = riskReason(op)
            val exists = if (op.action.equals("write", true)) withContext(Dispatchers.IO) { runCatching { Workspace.read(op.path, workspace, resolver); true }.getOrDefault(false) } else false
            if (danger != null || exists) {
                pendingRisk = danger ?: "This file already exists. Replacing it will overwrite its current contents."
                busy = false
                status = "Review this potentially risky action."
                return
            }
            execute(op)
            pendingOps = pendingOps.drop(1)
        }
        continueAgent()
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("KILLORA", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("AI STUDIO", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { newConversation() }) { Icon(Icons.Default.Add, "New chat", tint = Color.White) }
            IconButton(onClick = { showHistory = true }) { Icon(Icons.Default.History, "Chat history", tint = Color.White) }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FolderOpen, null, tint = Purple, modifier = Modifier.size(16.dp))
            Text(folder, color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.weight(1f).padding(start = 6.dp), maxLines = 1)
            TextButton(onClick = pickFolder, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)) { Text("Change", fontSize = 10.sp) }
            Text(if (busy) "WORKING" else model.ifBlank { "NO MODEL" }, color = if (busy) Color.Yellow else Color.Gray, fontSize = 9.sp, maxLines = 1)
        }
        Divider(color = Color(0xFF242838))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chat) { message ->
                val user = message.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (user) Color(0xFF34304F) else Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                        Text(message.text, Modifier.padding(horizontal = 14.dp, vertical = 11.dp), color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
                    }
                }
            }
            if (pendingOps.isNotEmpty()) {
                item {
                    val op = pendingOps.first()
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF30251B)), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("Confirmation needed", color = Color(0xFFFFC078), fontWeight = FontWeight.Bold)
                            Text(pendingRisk, color = Color.White, fontSize = 12.sp)
                            Text("${op.action.uppercase()}  ${op.path.ifBlank { op.command }}", color = Color.LightGray, fontSize = 11.sp)
                            if (op.action == "write") Text(op.content.take(900), color = Color.Gray, fontSize = 10.sp, maxLines = 8)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { pendingOps = emptyList(); status = "Action cancelled."; busy = false }) { Text("Cancel") }
                                Button(onClick = { scope.launch {
                                    busy = true
                                    try {
                                        execute(op); pendingOps = pendingOps.drop(1); processPending()
                                    } catch (e: Exception) { addMessage("assistant", "Action failed: ${e.message}"); pendingOps = emptyList(); busy = false }
                                } }) { Text("Confirm & continue") }
                            }
                        }
                    }
                }
            }
        }
        Text(status, color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 3.dp), maxLines = 2)
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 7.dp).background(Panel, RoundedCornerShape(24.dp)).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 9.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), decorationBox = { inner -> if (prompt.isEmpty()) Text("Message KILLORA...", color = Color.Gray, fontSize = 14.sp); inner() })
            IconButton(enabled = !busy && prompt.isNotBlank(), onClick = {
                val text = prompt.trim(); prompt = ""; task = text; agentHistory = emptyList(); agentStep = 0; buildRepairAttempts = 0; repairLimitReached = false
                addMessage("user", text); busy = true; status = "Thinking..."
                scope.launch { try { continueAgent() } catch (e: Exception) { addMessage("assistant", "Agent error: ${e.message}"); status = "Check API URL, key and model in Settings."; busy = false } }
            }) { Icon(Icons.Default.Send, "Send", tint = Purple) }
        }
    }

    if (showHistory) AlertDialog(onDismissRequest = { showHistory = false }, title = { Text("Chat history") }, text = {
        LazyColumn(Modifier.heightIn(max = 420.dp)) {
            items(conversations.sortedByDescending { it.updatedAt }) { c ->
                TextButton(onClick = { openConversation(c) }, modifier = Modifier.fillMaxWidth()) { Text(c.title, maxLines = 2, color = Color.White) }
            }
        }
    }, confirmButton = { TextButton(onClick = { newConversation() }) { Text("New chat") } }, dismissButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } })

    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("API & device settings") }, text = {
        Column(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("API Base URL") }, singleLine = true)
            OutlinedTextField(key, { key = it }, label = { Text("API Key (encrypted)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(model, { model = it }, label = { Text("Model ID") }, singleLine = true)
            OutlinedTextField(termuxPath, { termuxPath = it }, label = { Text("Termux workspace path") }, singleLine = true)
            Text("Changing provider, API key or model will NOT clear this chat. The same conversation continues with the newly selected model.", color = Color.Gray, fontSize = 11.sp)
            TextButton(onClick = { scope.launch { try { models = withContext(Dispatchers.IO) { api.fetchModels(ApiConfig(baseUrl, key, "")) }; status = "Found ${models.size} models." } catch (e: Exception) { status = "Model fetch failed: ${e.message}" } } }) { Text("Fetch models") }
            models.forEach { m -> TextButton(onClick = { model = m }) { Text(m, color = if (model == m) Purple else Color.White) } }
        }
    }, confirmButton = { Button(onClick = { scope.launch { prefs.saveProvider(baseUrl.trim(), key); prefs.saveModel(model.trim()); prefs.saveTermuxPath(termuxPath.trim()); showSettings = false; status = "Settings saved. Current chat preserved." } }) { Text("Save") } })
}

