package com.killora.aistudio

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.util.UUID

private val Context.studioStore by preferencesDataStore("killora_studio_secure")

data class ChatMessage(val role: String, val text: String, val time: Long = System.currentTimeMillis())
data class ChatConversation(val id: String = UUID.randomUUID().toString(), val title: String, val messages: List<ChatMessage>, val updatedAt: Long = System.currentTimeMillis())

class StudioPrefs(private val context: Context) {
    private val urlKey = stringPreferencesKey("base_url")
    private val encryptedApiKey = stringPreferencesKey("api_key_enc")
    private val modelKey = stringPreferencesKey("model")
    private val folderKey = stringPreferencesKey("folder_uri")
    private val termuxPathKey = stringPreferencesKey("termux_workspace_path")
    private val conversationsKey = stringPreferencesKey("conversations_v1")
    private val activeConversationKey = stringPreferencesKey("active_conversation_v1")

    suspend fun saveProvider(url: String, key: String) { context.studioStore.edit { it[urlKey] = url; it[encryptedApiKey] = encrypt(key) } }
    suspend fun saveModel(value: String) { context.studioStore.edit { it[modelKey] = value } }
    suspend fun saveFolder(value: String) { context.studioStore.edit { it[folderKey] = value } }
    suspend fun saveTermuxPath(value: String) { context.studioStore.edit { it[termuxPathKey] = value } }
    suspend fun baseUrl() = context.studioStore.data.first()[urlKey]
    suspend fun apiKey(): String? = context.studioStore.data.first()[encryptedApiKey]?.let(::decrypt)
    suspend fun model() = context.studioStore.data.first()[modelKey]
    suspend fun folder() = context.studioStore.data.first()[folderKey]
    suspend fun termuxPath() = context.studioStore.data.first()[termuxPathKey]
    suspend fun activeConversationId() = context.studioStore.data.first()[activeConversationKey]
    suspend fun saveActiveConversation(id: String) { context.studioStore.edit { it[activeConversationKey] = id } }
    suspend fun conversations(): List<ChatConversation> {
        val raw = context.studioStore.data.first()[conversationsKey] ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i); val msgs = o.optJSONArray("messages") ?: JSONArray()
                ChatConversation(o.optString("id"), o.optString("title", "New chat"),
                    (0 until msgs.length()).map { j -> val m = msgs.getJSONObject(j); ChatMessage(m.optString("role"), m.optString("text"), m.optLong("time")) }, o.optLong("updatedAt"))
            }
        }.getOrDefault(emptyList())
    }
    suspend fun saveConversations(items: List<ChatConversation>) {
        val arr = JSONArray()
        items.take(80).forEach { c ->
            val ms = JSONArray(); c.messages.takeLast(300).forEach { m -> ms.put(JSONObject().put("role",m.role).put("text",m.text).put("time",m.time)) }
            arr.put(JSONObject().put("id",c.id).put("title",c.title).put("updatedAt",c.updatedAt).put("messages",ms))
        }
        context.studioStore.edit { it[conversationsKey] = arr.toString() }
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }
    private fun encrypt(value: String): String { val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, secretKey()); return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP) }
    private fun decrypt(value: String): String { val raw = Base64.decode(value, Base64.NO_WRAP); val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, raw.copyOfRange(0,12))); return cipher.doFinal(raw.copyOfRange(12,raw.size)).toString(Charsets.UTF_8) }
    companion object { private const val KEY_ALIAS = "killora_ai_studio_api_key_v1" }
}
