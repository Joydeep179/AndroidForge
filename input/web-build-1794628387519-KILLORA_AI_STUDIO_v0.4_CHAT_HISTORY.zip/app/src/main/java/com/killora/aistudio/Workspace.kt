package com.killora.aistudio

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import java.io.ByteArrayOutputStream

object Workspace {
    suspend fun execute(op: FileOperation, tree: Uri?, resolver: ContentResolver, terminal: TermuxBridge): String {
        return when (op.action.lowercase()) {
            "list" -> list(op.path, tree, resolver)
            "read" -> read(op.path, tree, resolver)
            "mkdir" -> mkdir(op.path, tree, resolver)
            "write" -> write(op.path, op.content, tree, resolver)
            "terminal" -> terminal.run(op.command)
            else -> error("Unsupported agent action: ${op.action}")
        }
    }

    private fun safeParts(path: String): List<String> {
        require(path.isNotBlank() && !path.startsWith("/") && '\\' !in path) { "Only relative workspace paths are allowed." }
        val parts = path.split('/').filter { it.isNotBlank() }
        require(parts.isNotEmpty() && parts.none { it == "." || it == ".." }) { "Unsafe path rejected." }
        require(parts.all { it.matches(Regex("[A-Za-z0-9._ -]{1,100}")) }) { "Unsupported filename." }
        return parts
    }
    private fun root(tree: Uri?): Uri {
        require(tree != null) { "Select a workspace folder." }
        return DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    }
    private fun child(resolver: ContentResolver, tree: Uri, parent: Uri, name: String): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent))
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            val id = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val display = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (c.moveToNext()) if (c.getString(display) == name)
                return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(id))
        }
        return null
    }
    private fun resolve(path: String, tree: Uri?, resolver: ContentResolver, createParents: Boolean): Pair<Uri, String> {
        val t = tree ?: error("Select a workspace folder.")
        val parts = safeParts(path)
        var parent = root(t)
        for (p in parts.dropLast(1)) {
            parent = child(resolver, t, parent, p) ?: if (createParents)
                DocumentsContract.createDocument(resolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, p) ?: error("Cannot create $p")
            else error("Folder not found: $p")
        }
        return parent to parts.last()
    }
    fun list(path: String, tree: Uri?, resolver: ContentResolver): String {
        val t = tree ?: error("Select a workspace folder.")
        val dir = if (path.isBlank() || path == ".") root(t) else {
            val (p,n) = resolve(path,t,resolver,false)
            child(resolver,t,p,n) ?: error("Directory not found: $path")
        }
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getDocumentId(dir))
        val names = mutableListOf<String>()
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null,null,null)?.use { c ->
            val n = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val m = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (c.moveToNext()) names += (if (c.getString(m) == DocumentsContract.Document.MIME_TYPE_DIR) "[DIR] " else "[FILE] ") + c.getString(n)
        }
        return if (names.isEmpty()) "(empty folder)" else names.joinToString("\n").take(12000)
    }
    fun read(path: String, tree: Uri?, resolver: ContentResolver): String {
        val t = tree ?: error("Select a workspace folder.")
        val (p,n) = resolve(path,t,resolver,false)
        val file = child(resolver,t,p,n) ?: error("File not found: $path")
        val out = ByteArrayOutputStream()
        resolver.openInputStream(file)?.use { input ->
            val buf = ByteArray(8192); var total = 0
            while (true) {
                val count = input.read(buf); if (count < 0) break
                total += count; require(total <= 256 * 1024) { "Read limit is 256 KB per file." }; out.write(buf,0,count)
            }
        } ?: error("Cannot read $path")
        return out.toString("UTF-8")
    }
    fun mkdir(path: String, tree: Uri?, resolver: ContentResolver): String {
        val t = tree ?: error("Select a workspace folder.")
        val (p,n) = resolve(path,t,resolver,true)
        if (child(resolver,t,p,n) == null)
            DocumentsContract.createDocument(resolver,p,DocumentsContract.Document.MIME_TYPE_DIR,n) ?: error("Cannot create $path")
        return "Folder ready: $path"
    }
    fun write(path: String, content: String, tree: Uri?, resolver: ContentResolver): String {
        val t = tree ?: error("Select a workspace folder.")
        val (p,n) = resolve(path,t,resolver,true)
        val existing = child(resolver,t,p,n)
        val mime = when (n.substringAfterLast('.', "").lowercase()) {
            "html" -> "text/html"; "css" -> "text/css"; "js" -> "text/javascript"; "json" -> "application/json"
            "md" -> "text/markdown"; "txt","kt","py","sh" -> "text/plain"; "xml" -> "text/xml"; else -> "application/octet-stream"
        }
        val target = existing ?: DocumentsContract.createDocument(resolver,p,mime,n) ?: error("Cannot create $path")
        resolver.openOutputStream(target,"wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) } ?: error("Cannot write $path")
        return (if (existing == null) "Created " else "Updated ") + path
    }
}
