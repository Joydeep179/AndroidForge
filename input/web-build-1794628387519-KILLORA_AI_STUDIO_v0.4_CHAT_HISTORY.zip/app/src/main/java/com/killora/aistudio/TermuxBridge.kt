package com.killora.aistudio

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicInteger

/** Result-returning Termux RUN_COMMAND bridge (Termux >= 0.109). */
class TermuxBridge(private val context: Context, private val workspacePath: String) {
    suspend fun run(command: String): String {
        require(workspacePath.startsWith("/storage/") || workspacePath.startsWith("/sdcard/") || workspacePath.startsWith("/data/data/com.termux/")) {
            "Set a valid Termux workspace path in Settings first."
        }
        require(command.isNotBlank() && command.length <= 4000) { "Invalid terminal command (max 4000 characters)." }
        val lower = command.lowercase()
        val blocked = listOf("rm -rf", "mkfs", "dd if=", "chmod -r 777", "chown -r", "shutdown", "reboot", " su", "sudo ", ">/dev/")
        require(blocked.none { lower.contains(it) }) { "Potentially destructive command blocked." }
        require(!Regex("(^|[;&|])\\s*(curl|wget)\\b.*(\\|\\s*(sh|bash)|\\|\\s*\\w+)").containsMatchIn(lower)) {
            "Piping downloaded content to a shell is blocked."
        }

        val id = nextId.incrementAndGet()
        val deferred = CompletableDeferred<TermuxCommandResult>()
        TermuxResultBus.register(id, deferred)
        val callback = Intent(context, PluginResultsService::class.java).putExtra(PluginResultsService.EXTRA_EXECUTION_ID, id)
        val pendingFlags = PendingIntent.FLAG_ONE_SHOT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
        val resultPendingIntent = PendingIntent.getService(context, id, callback, pendingFlags)
        val safePath = workspacePath.replace("'", "'\\''")
        val intent = Intent("com.termux.RUN_COMMAND").apply {
            setClassName("com.termux", "com.termux.app.RunCommandService")
            putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", "cd '$safePath' && $command"))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", workspacePath)
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", resultPendingIntent)
            putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", "KILLORA AI Studio")
            putExtra("com.termux.RUN_COMMAND_COMMAND_DESCRIPTION", "User-approved command. Output is returned to KILLORA AI Studio.")
        }
        try {
            context.startService(intent)
        } catch (e: Exception) {
            TermuxResultBus.remove(id)
            resultPendingIntent.cancel()
            throw IllegalStateException("Could not start Termux: ${e.message}. Check Termux installation, RUN_COMMAND permission and allow-external-apps=true.", e)
        }

        val result = try {
            withTimeout(COMMAND_TIMEOUT_MS) { deferred.await() }
        } catch (e: Exception) {
            TermuxResultBus.remove(id)
            throw IllegalStateException("Timed out waiting for Termux result. Check Termux is running and the command has finished.", e)
        }
        val output = buildString {
            append("EXIT_CODE=${result.exitCode}\n")
            if (result.termuxErrorCode != -1) append("TERMUX_ERROR=${result.termuxErrorCode}: ${result.termuxErrorMessage}\n")
            append("--- STDOUT ---\n").append(result.stdout.takeLast(MAX_OUTPUT_CHARS))
            if (result.stderr.isNotBlank()) append("\n--- STDERR ---\n").append(result.stderr.takeLast(MAX_OUTPUT_CHARS))
            if (result.stdoutOriginalLength > result.stdout.length || result.stderrOriginalLength > result.stderr.length)
                append("\n[Termux truncated large output; original stdout=${result.stdoutOriginalLength}, stderr=${result.stderrOriginalLength}]")
        }
        return output
    }

    companion object {
        private val nextId = AtomicInteger(1000)
        private const val COMMAND_TIMEOUT_MS = 10 * 60 * 1000L
        private const val MAX_OUTPUT_CHARS = 20000
    }
}

data class TermuxCommandResult(
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val termuxErrorCode: Int,
    val termuxErrorMessage: String,
    val stdoutOriginalLength: Int,
    val stderrOriginalLength: Int
)
