package com.killora.aistudio

/** Lightweight Gradle failure classifier; full logs are still passed to the configured AI model. */
object BuildDiagnostics {
    data class Report(val isBuildCommand: Boolean, val exitCode: Int?, val failed: Boolean, val summary: String, val relevantLines: String)

    fun inspect(command: String, output: String): Report {
        val buildCommand = Regex("(?i)(\\bgradle\\b|gradlew|assemble[A-Z]|build\\s*--|test\\s*--tests)").containsMatchIn(command)
        val code = Regex("(?m)^EXIT_CODE=(-?\\d+)").find(output)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val failed = buildCommand && code != null && code != 0
        val lines = output.lines()
        val patterns = listOf(
            Regex("(?i)\\b(e:|error:|failed|failure|exception|could not|cannot find|unresolved reference|duplicate class|manifest merger failed|execution failed|compilation error|unsupported class file)\\b"),
            Regex("(?i)^\\s*at .+\\(.+\\.java:\\d+\\)")
        )
        val hits = lines.withIndex().filter { (_, line) -> patterns.any { it.containsMatchIn(line) } }
        val selected = linkedSetOf<Int>()
        hits.forEach { (i, _) -> for (j in (i - 1).coerceAtLeast(0)..(i + 1).coerceAtMost(lines.lastIndex)) selected += j }
        val excerpts = selected.sorted().take(100).joinToString("\n") { lines[it] }.take(12000)
        val summary = when {
            !buildCommand -> "Not detected as a Gradle/build command."
            code == null -> "Build output received, but no exit code was parsed."
            code == 0 -> "Build passed (exit code 0)."
            excerpts.contains("Could not resolve") || excerpts.contains("could not resolve") -> "Dependency resolution failure. Check repository/network/dependency coordinates."
            excerpts.contains("Unresolved reference", true) -> "Kotlin unresolved reference/compile error."
            excerpts.contains("Manifest merger failed", true) -> "Android manifest merge failure."
            excerpts.contains("Unsupported class file", true) -> "Possible JDK/Gradle compatibility mismatch."
            else -> "Build failed with exit code $code. AI should inspect the full log and relevant source files."
        }
        return Report(buildCommand, code, failed, summary, excerpts)
    }
}
