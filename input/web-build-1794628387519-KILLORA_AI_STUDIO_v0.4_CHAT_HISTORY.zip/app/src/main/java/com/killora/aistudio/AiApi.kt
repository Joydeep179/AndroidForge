package com.killora.aistudio

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ApiConfig(val baseUrl: String, val apiKey: String, val model: String)
data class AgentPlan(val summary: String, val operations: List<FileOperation>, val done: Boolean = false)
data class FileOperation(val action: String, val path: String, val content: String = "", val command: String = "")

class AiApi {
    private val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).build()

    fun fetchModels(c: ApiConfig): List<String> {
        validate(c)
        val req = Request.Builder().url(c.baseUrl.trimEnd('/') + "/models")
            .header("Authorization", "Bearer ${c.apiKey}").get().build()
        client.newCall(req).execute().use { res ->
            val body = res.body?.string().orEmpty()
            if (!res.isSuccessful) error("HTTP ${res.code}: ${body.take(300)}")
            val arr = JSONObject(body).optJSONArray("data") ?: JSONArray()
            return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("id") }
                .filter { it.isNotBlank() }.distinct().sorted()
        }
    }

    fun nextAgentStep(c: ApiConfig, userPrompt: String, history: List<String>, conversation: List<ChatMessage> = emptyList()): AgentPlan {
        validate(c)
        require(c.model.isNotBlank()) { "Select a model first." }
        val system = """
You are KILLORA AI STUDIO, an Android coding agent operating in a user-selected workspace.
Return ONLY JSON: {"summary":"what this step does","done":false,"operations":[...]}.
Allowed operation shapes:
{"action":"list","path":"relative/folder"}
{"action":"read","path":"relative/file"}
{"action":"mkdir","path":"relative/folder"}
{"action":"write","path":"relative/file","content":"complete file text"}
{"action":"terminal","command":"one shell command"}
Use only relative paths, never absolute paths or .. . Max 12 operations per step.
Prefer list/read before editing existing projects. For write, provide complete file content.
Use terminal only for ordinary project commands such as git status, tests, and Gradle builds (./gradlew assembleDebug or gradle assembleDebug).
BUILD SELF-REPAIR RULES:
- When workspace history contains BUILD_FAILURE, treat it as the highest-priority task. Read the named source/config files before proposing changes.
- Diagnose the actual compiler/build log; do not guess or rewrite unrelated files. Prefer the smallest targeted fix.
- Propose minimal file changes as write operations with complete file contents.
- The app automatically executes ordinary safe operations. It separately asks the user only for potentially destructive or security-sensitive actions.
- After fixes, propose the same build command again as a terminal operation so the result is verified.
- If the build still fails, use the new logs and make another targeted proposal. Never claim success unless a captured exit code is 0.
- If logs show missing SDK/JDK/dependencies or an environment problem, explain the setup command instead of changing source code blindly.
Do not run destructive commands, privilege escalation, downloads piped to shell, or commands that access secrets.
If all requested work is finished, set done=true and operations=[].
""".trimIndent()
        val context = history.takeLast(16).joinToString("\n\n").takeLast(42000)
        val msgs = JSONArray().put(JSONObject().put("role","system").put("content",system))
        conversation.takeLast(30).forEach { m ->
            if (m.role == "user" || m.role == "assistant") msgs.put(JSONObject().put("role", m.role).put("content", m.text.take(12000)))
        }
        msgs.put(JSONObject().put("role","user").put("content","CURRENT TASK:\n$userPrompt\n\nWORKSPACE RESULTS SO FAR:\n$context\n\nReturn the next small step as JSON."))
        val payload = JSONObject().put("model",c.model).put("messages",msgs).put("temperature",0.15)
        val req = Request.Builder().url(c.baseUrl.trimEnd('/') + "/chat/completions")
            .header("Authorization","Bearer ${c.apiKey}").header("Content-Type","application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { res ->
            val body = res.body?.string().orEmpty()
            if (!res.isSuccessful) error("HTTP ${res.code}: ${body.take(500)}")
            val raw = JSONObject(body).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val json = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val obj = JSONObject(json)
            val arr = obj.optJSONArray("operations") ?: JSONArray()
            require(arr.length() <= 12) { "Agent step exceeds 12 operations." }
            val ops = (0 until arr.length()).map { i ->
                val x = arr.getJSONObject(i)
                FileOperation(x.getString("action"), x.optString("path",""), x.optString("content",""), x.optString("command",""))
            }
            AgentPlan(obj.optString("summary","Agent step"), ops, obj.optBoolean("done",false))
        }
    }
    private fun validate(c: ApiConfig) {
        require(c.baseUrl.startsWith("https://")) { "HTTPS API URL required." }
        require(c.apiKey.isNotBlank()) { "API key is empty." }
    }
}
