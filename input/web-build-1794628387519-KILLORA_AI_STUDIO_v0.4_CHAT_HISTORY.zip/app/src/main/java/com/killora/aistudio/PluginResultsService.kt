package com.killora.aistudio

import android.app.IntentService
import android.content.Intent
import android.os.Bundle
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import java.util.concurrent.ConcurrentHashMap

/** Receives the one-shot PendingIntent callback sent by Termux after command completion. */
class PluginResultsService : IntentService("KILLORA-TermuxResults") {
    override fun onHandleIntent(intent: Intent?) {
        if (intent == null) return
        val id = intent.getIntExtra(EXTRA_EXECUTION_ID, 0)
        val bundle: Bundle? = intent.getBundleExtra(EXTRA_RESULT_BUNDLE)
        if (bundle == null) {
            TermuxResultBus.complete(id, TermuxCommandResult("", "Termux returned no result bundle.", -1, -1, "Missing result bundle", 0, 0))
            return
        }
        val stdout = bundle.getString(KEY_STDOUT).orEmpty()
        val stderr = bundle.getString(KEY_STDERR).orEmpty()
        val result = TermuxCommandResult(
            stdout = stdout,
            stderr = stderr,
            exitCode = bundle.getInt(KEY_EXIT_CODE, -1),
            termuxErrorCode = bundle.getInt(KEY_ERR, -1),
            termuxErrorMessage = bundle.getString(KEY_ERRMSG).orEmpty(),
            stdoutOriginalLength = bundle.get(KEY_STDOUT_LENGTH)?.toString()?.toIntOrNull() ?: stdout.length,
            stderrOriginalLength = bundle.get(KEY_STDERR_LENGTH)?.toString()?.toIntOrNull() ?: stderr.length
        )
        Log.i("KILLORA-Termux", "Command $id finished with exit=${result.exitCode}, stdout=${stdout.length}, stderr=${stderr.length}")
        TermuxResultBus.complete(id, result)
    }

    companion object {
        const val EXTRA_EXECUTION_ID = "execution_id"
        private const val EXTRA_RESULT_BUNDLE = "result"
        private const val KEY_STDOUT = "stdout"
        private const val KEY_STDERR = "stderr"
        private const val KEY_EXIT_CODE = "exitCode"
        private const val KEY_ERR = "err"
        private const val KEY_ERRMSG = "errmsg"
        private const val KEY_STDOUT_LENGTH = "stdout_original_length"
        private const val KEY_STDERR_LENGTH = "stderr_original_length"
    }
}

/** In-process rendezvous between the bridge coroutine and the result service. */
object TermuxResultBus {
    private val waiting = ConcurrentHashMap<Int, CompletableDeferred<TermuxCommandResult>>()
    fun register(id: Int, deferred: CompletableDeferred<TermuxCommandResult>) { waiting[id] = deferred }
    fun remove(id: Int) { waiting.remove(id) }
    fun complete(id: Int, result: TermuxCommandResult) { waiting.remove(id)?.complete(result) }
}
