# KILLORA AI STUDIO 0.4.0 — Chat-first Agent

Native Android Studio project (Kotlin + Jetpack Compose). Open with Android Studio, JDK 17 and Android SDK 35.

## 0.4 updates
- ChatGPT-style compact mobile conversation layout with user/assistant bubbles, a fixed bottom composer, and a scrollable chat area.
- Persistent chat history stored locally using Android DataStore. Up to 80 conversations and 300 messages per conversation are retained.
- New Chat and Chat History controls let the user start a separate conversation or reopen an earlier one.
- The active conversation is retained when changing API base URL, API key, or model. Conversation messages are sent as context when the agent continues with the new provider/model.
- Ordinary low-risk operations (listing/reading workspace files, creating folders, creating new files, and ordinary build/test terminal commands) run without per-action approval.
- A confirmation is shown for detected destructive/security-sensitive terminal commands and overwriting an existing file.
- API key remains encrypted with Android Keystore AES-GCM.
- Agent still has a 12-step task limit and up to 3 build-repair attempts.

## Safety note
The risk check is a lightweight command-pattern guard, not a sandbox. Do not run untrusted code or commands in a workspace containing secrets. Keep backups or use Git. Review any confirmation prompt before proceeding. Ordinary terminal commands are not guaranteed harmless merely because they do not match the guard patterns.

## API requirements
OpenAI-compatible HTTPS provider:
- `GET {baseUrl}/models` returning `data[].id`
- `POST {baseUrl}/chat/completions` returning `choices[0].message.content`
- Configure base URL ending in `/v1`, API key and model in Settings.

## Build
Build the APK with Android Studio / Gradle using JDK 17 and Android SDK 35. The project does not include a Gradle wrapper.
