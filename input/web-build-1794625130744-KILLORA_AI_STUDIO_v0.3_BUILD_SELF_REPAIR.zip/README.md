# KILLORA AI STUDIO 0.3.0 — Build Self-Repair Agent

Native Android Studio project (Kotlin + Jetpack Compose). Open with Android Studio, JDK 17 and Android SDK 35.

## What's new in 0.3
- **Termux result capture:** Uses Termux `RUN_COMMAND` with a one-shot mutable `PendingIntent` callback. Captures stdout, stderr, exit code and Termux-side errors when the command completes.
- **Background command execution:** Build/test commands run as Termux background jobs so stdout and stderr are returned separately.
- **Gradle build detection:** Recognizes Gradle/Gradle wrapper build commands and reads the returned exit code.
- **Build diagnostics:** Extracts likely compiler, dependency, manifest and toolchain error lines while retaining the captured output in agent history.
- **AI self-repair loop:** On a failed Gradle build, the agent is instructed to inspect logs and relevant files, propose minimal fixes, then rerun the build. Up to 3 repair attempts are allowed.
- **Human approval remains mandatory:** Every terminal command and every file write/edit still requires explicit approval. Existing-file overwrites require the separate overwrite confirmation.
- Agent task limit increased to 12 planning steps per task.

## Termux requirements and setup
1. Install a recent Termux build (minimum **0.109** for result callbacks; use the current F-Droid/GitHub build).
2. In Termux, edit `~/.termux/termux.properties` and set:
   ```properties
   allow-external-apps=true
   ```
   Restart Termux after changing it.
3. In Android Settings, open KILLORA AI STUDIO app permissions and grant **Run commands in Termux environment** / `com.termux.permission.RUN_COMMAND`.
4. In Termux, run:
   ```bash
   termux-setup-storage
   pkg update
   pkg install openjdk-17 gradle git
   ```
   Accept the storage permission prompt. If your project needs Android builds, install/configure the Android SDK and required platform/build-tools in Termux too.
5. In KILLORA Settings, set the Termux workspace path to the exact same directory as the selected SAF workspace. Example:
   `/storage/emulated/0/Projects/MyAndroidProject`
6. Select that same folder in the app. Check that Termux can `cd` into it and read/write files.
7. Ask the agent to run a build, for example: `Run gradle assembleDebug in this project, analyse any failure, fix it with my approval, and rerun until it passes or reaches the repair limit.`

## How self-repair works
- The agent proposes a terminal build command. You approve it.
- KILLORA waits for Termux's result callback and captures output/exit status.
- A non-zero exit code on a detected build command is marked `BUILD_FAILURE`; relevant diagnostic lines and the log are added to the AI's context.
- The AI can then propose file reads and targeted file writes. You approve each action; overwrite confirmation is shown for existing files.
- After edits, the AI must propose a new build command. Only exit code `0` is treated as verified success.
- Maximum 3 automatic repair cycles; maximum 12 agent planning steps per task. If Termux times out, returns no result, or output is truncated, the app reports that instead of pretending the build passed.

## API requirements
OpenAI-compatible HTTPS provider:
- `GET {baseUrl}/models` returning `data[].id`
- `POST {baseUrl}/chat/completions` returning `choices[0].message.content`
- Configure base URL ending in `/v1`, API key and model in Settings.

## Important limitations / safety
- Termux returns command output only after command completion; this is **not live streaming**. Termux limits returned stdout+stderr to roughly 100 KB combined, so large logs can be truncated. KILLORA also limits text passed into chat history.
- Requires Termux >= 0.109, `allow-external-apps=true`, and Android permission grant. Termux's own setup or permission errors are shown in the captured result where available.
- The app's Termux workspace path and Android SAF-selected folder must refer to the same physical directory. This mapping is configured manually.
- The AI does not edit files autonomously: each proposed operation needs approval. AI-generated code can still be wrong; review changes and keep backups/version control.
- Command blocking is a basic guard, not a security sandbox. Approve only commands you understand and trust. Avoid using this with untrusted prompts or projects containing secrets.
- Build verification depends on a working JDK, Android SDK, Gradle, Android SDK licences and project-specific dependencies inside Termux. Exit code 0 confirms the invoked command succeeded, not that the app was installed or manually tested on a device.
- Workspace file operations remain text-oriented; read limit is 256 KB per file and binary editing is not supported.
- No Gradle wrapper is bundled in this project. Use an installed `gradle` command unless you add the project's own trusted wrapper.
