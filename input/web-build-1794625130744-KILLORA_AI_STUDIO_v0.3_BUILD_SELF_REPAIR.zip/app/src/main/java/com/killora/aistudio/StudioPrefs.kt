package com.killora.aistudio

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.studioStore by preferencesDataStore("killora_studio_secure")

class StudioPrefs(private val context: Context) {
    private val urlKey = stringPreferencesKey("base_url")
    private val encryptedApiKey = stringPreferencesKey("api_key_enc")
    private val modelKey = stringPreferencesKey("model")
    private val folderKey = stringPreferencesKey("folder_uri")
    private val termuxPathKey = stringPreferencesKey("termux_workspace_path")

    suspend fun saveProvider(url: String, key: String) {
        context.studioStore.edit {
            it[urlKey] = url
            it[encryptedApiKey] = encrypt(key)
        }
    }
    suspend fun saveModel(value: String) { context.studioStore.edit { it[modelKey] = value } }
    suspend fun saveFolder(value: String) { context.studioStore.edit { it[folderKey] = value } }
    suspend fun saveTermuxPath(value: String) { context.studioStore.edit { it[termuxPathKey] = value } }
    suspend fun baseUrl() = context.studioStore.data.first()[urlKey]
    suspend fun apiKey(): String? = context.studioStore.data.first()[encryptedApiKey]?.let(::decrypt)
    suspend fun model() = context.studioStore.data.first()[modelKey]
    suspend fun folder() = context.studioStore.data.first()[folderKey]
    suspend fun termuxPath() = context.studioStore.data.first()[termuxPathKey]

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }
    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }
    private fun decrypt(value: String): String {
        val raw = Base64.decode(value, Base64.NO_WRAP)
        val iv = raw.copyOfRange(0, 12)
        val payload = raw.copyOfRange(12, raw.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return cipher.doFinal(payload).toString(Charsets.UTF_8)
    }
    companion object { private const val KEY_ALIAS = "killora_ai_studio_api_key_v1" }
}
