package com.killora.aistudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF171B2A)
private val Purple = Color(0xFF8B5CF6)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { StudioPrefs(applicationContext) }
    private val api by lazy { AiApi() }
    private var workspace by mutableStateOf<Uri?>(null)
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            workspace = uri
            lifecycleScope.launch { prefs.saveFolder(uri.toString()) }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch { workspace = prefs.folder()?.let(Uri::parse) }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
                StudioScreen(prefs, api, workspace, workspace?.lastPathSegment ?: "No folder selected", { picker.launch(null) }, contentResolver, this)
            }
        }
    }
}

@Composable
private fun StudioScreen(
    prefs: StudioPrefs, api: AiApi, workspaceTree: Uri?, folder: String, pickFolder: () -> Unit,
    resolver: android.content.ContentResolver, activity: ComponentActivity
) {
    val scope = rememberCoroutineScope()
    var baseUrl by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var models by remember { mutableStateOf(listOf<String>()) }
    var termuxPath by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Add your API provider in Settings.") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showOverwrite by remember { mutableStateOf(false) }
    var overwriteOp by remember { mutableStateOf<FileOperation?>(null) }
    var pendingOps by remember { mutableStateOf<List<FileOperation>>(emptyList()) }
    var pendingIndex by remember { mutableIntStateOf(0) }
    var task by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var chat by remember { mutableStateOf(listOf("KILLORA AI STUDIO v0.3 — Termux output capture + Gradle self-repair. Connect an API to begin.")) }
    var agentStep by remember { mutableIntStateOf(0) }
    var buildRepairAttempts by remember { mutableIntStateOf(0) }
    var repairLimitReached by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        baseUrl = prefs.baseUrl() ?: ""; key = prefs.apiKey() ?: ""; model = prefs.model() ?: ""
        termuxPath = prefs.termuxPath() ?: ""
    }

    fun append(line: String) { chat = chat + line }
    suspend fun continueAgent() {
        if (repairLimitReached) { status = "Stopped after 3 failed build attempts. Review the logs before starting a new task."; busy = false; return }
        if (agentStep >= 12) { status = "Paused after 12 agent steps. Review the latest logs and continue if needed."; busy = false; return }
        agentStep++
        val cfg = ApiConfig(baseUrl, key, model)
        val next = withContext(Dispatchers.IO) { api.nextAgentStep(cfg, task, history) }
        append("Agent step $agentStep: ${next.summary}")
        status = "Agent is planning the next approved action…"
        if (next.done || next.operations.isEmpty()) {
            append("Agent reports task complete.")
            status = "Agent finished. Review the workspace."
            busy = false
            return
        }
        pendingOps = next.operations
        pendingIndex = 0
        status = "Approve each proposed action to continue."
        busy = false
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("KILLORA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("AI STUDIO  /  BUILD SELF-REPAIR AGENT", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderOpen, null, tint = Purple)
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("WORKSPACE", color = Color.Gray, fontSize = 10.sp)
                    Text(folder, color = Color.White, maxLines = 1)
                }
                TextButton(onClick = pickFolder) { Text("SELECT") }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MODEL:", color = Color.Gray, fontSize = 11.sp)
            var expanded by remember { mutableStateOf(false) }
            Box {
                TextButton(onClick = { expanded = true }) { Text(model.ifBlank { "Choose model" }) }
                DropdownMenu(expanded, { expanded = false }) {
                    models.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = {
                        model = item; expanded = false; scope.launch { prefs.saveModel(item) }
                    }) }
                }
            }
            Spacer(Modifier.weight(1f))
            Text(if (busy) "AGENT WORKING" else "READY", color = if (busy) Color.Yellow else Color(0xFF34D399), fontSize = 10.sp)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chat) { line ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Text(line, Modifier.padding(12.dp), color = Color.White, fontSize = 13.sp)
                }
            }
            if (pendingOps.isNotEmpty() && pendingIndex < pendingOps.size) {
                item {
                    val op = pendingOps[pendingIndex]
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF29213D))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Approval required (${pendingIndex + 1}/${pendingOps.size})", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${op.action.uppercase()} ${op.path.ifBlank { op.command }}", color = Color.LightGray)
                            if (op.action == "write") Text(op.content.take(1600), color = Color.Gray, fontSize = 11.sp)
                            Row {
                                TextButton(onClick = { pendingOps = emptyList(); status = "Agent step rejected."; busy = false }) { Text("Reject step") }
                                Button(onClick = {
                                    val selected = op
                                    scope.launch {
                                        busy = true
                                        try {
                                            if (selected.action == "write") {
                                                val existing = withContext(Dispatchers.IO) { runCatching { Workspace.read(selected.path, workspaceTree, resolver) }.getOrNull() }
                                                if (existing != null) {
                                                    overwriteOp = selected
                                                    showOverwrite = true
                                                    busy = false
                                                    return@launch
                                                }
                                            }
                                            val result = withContext(Dispatchers.IO) {
                                                Workspace.execute(selected, workspaceTree, resolver, TermuxBridge(activity, termuxPath))
                                            }
                                            history = history + "ACTION ${selected.action} ${selected.path.ifBlank { selected.command }}\nRESULT $result"
                                            append(result)
                                            if (selected.action.equals("terminal", true)) {
                                                val report = BuildDiagnostics.inspect(selected.command, result)
                                                if (report.isBuildCommand) {
                                                    append("BUILD CHECK: ${report.summary}")
                                                    history = history + "BUILD_DIAGNOSTIC: ${report.summary}\nRELEVANT LOG EXCERPT:\n${report.relevantLines}"
                                                    if (report.failed) {
                                                        history = history + "BUILD_FAILURE: exit=${report.exitCode}; ${report.summary}"
                                                        buildRepairAttempts++
                                                        if (buildRepairAttempts < 3) {
                                                            task = task + "\n\nAUTOMATIC BUILD SELF-REPAIR REQUIRED (attempt $buildRepairAttempts of 3): The most recent Gradle build failed. Analyse BUILD_DIAGNOSTIC and the full captured output in history. Read the relevant files, propose minimal fixes for user approval, then rerun the same build command and verify its captured exit code. Do not claim success before exit code 0."
                                                            status = "Gradle failed. AI is preparing a log-based repair proposal ($buildRepairAttempts/3)."
                                                        } else {
                                                            repairLimitReached = true
                                                            status = "Build still fails after 3 attempts. Automatic repair stopped; review logs and environment."
                                                        }
                                                    } else if (report.exitCode == 0) {
                                                        status = "Build verified successfully (exit code 0)."
                                                        buildRepairAttempts = 0
                                                        repairLimitReached = false
                                                    } else {
                                                        status = "Build result needs review: ${report.summary}"
                                                    }
                                                }
                                            }
                                            pendingIndex++
                                            if (pendingIndex >= pendingOps.size) {
                                                pendingOps = emptyList()
                                                if (repairLimitReached) busy = false else continueAgent()
                                            } else busy = false
                                        } catch (e: Exception) { append("Action failed: ${e.message}"); busy = false }
                                    }
                                }) { Text("Approve action") }
                            }
                        }
                    }
                }
            }
        }
        Text(status, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(prompt, { prompt = it }, Modifier.weight(1f).padding(8.dp),
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                decorationBox = { inner -> if (prompt.isEmpty()) Text("Build, edit, debug a project...", color = Color.Gray); inner() })
            IconButton(enabled = !busy, onClick = {
                val text = prompt.trim()
                if (text.isNotEmpty()) {
                    prompt = ""; task = text; history = emptyList(); agentStep = 0; buildRepairAttempts = 0; repairLimitReached = false
                    append("You: $text"); busy = true
                    scope.launch {
                        try { continueAgent() }
                        catch (e: Exception) { append("Agent error: ${e.message}"); status = "Check API settings and model."; busy = false }
                    }
                }
            }) { Icon(Icons.Default.Send, "Send", tint = Purple) }
        }
    }

    if (showOverwrite && overwriteOp != null) {
        AlertDialog(onDismissRequest = { showOverwrite = false }, title = { Text("Overwrite existing file?") },
            text = { Text("The file ${overwriteOp!!.path} already exists. The agent wants to replace its contents. This cannot be undone automatically. Approve overwrite?") },
            confirmButton = { Button(onClick = {
                val op = overwriteOp!!; showOverwrite = false; overwriteOp = null; busy = true
                scope.launch {
                    try {
                        val result = withContext(Dispatchers.IO) { Workspace.write(op.path, op.content, workspaceTree, resolver) }
                        history = history + "UPDATED ${op.path}\nRESULT $result"; append(result)
                        pendingIndex++
                        if (pendingIndex >= pendingOps.size) { pendingOps = emptyList(); continueAgent() } else busy = false
                    } catch (e: Exception) { append("Overwrite failed: ${e.message}"); busy = false }
                }
            }) { Text("Overwrite") } },
            dismissButton = { TextButton(onClick = { showOverwrite = false; overwriteOp = null; pendingOps = emptyList(); status = "Overwrite cancelled."; }) { Text("Cancel") } })
    }

    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Provider & terminal settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("API Base URL") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, label = { Text("API Key (encrypted)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    OutlinedTextField(termuxPath, { termuxPath = it }, label = { Text("Termux workspace path (optional)") }, singleLine = true)
                    Text("OpenAI-compatible /v1 endpoint. Termux must be installed and RUN_COMMAND permission enabled.", color = Color.Gray, fontSize = 10.sp)
                    Text(status, color = Color.Gray, fontSize = 10.sp)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        busy = true
                        scope.launch {
                            try { models = withContext(Dispatchers.IO) { api.fetchModels(ApiConfig(baseUrl,key,"")) }; status = "Found ${models.size} models." }
                            catch (e: Exception) { status = "Fetch failed: ${e.message}" }
                            busy = false
                        }
                    }) { Text("FETCH MODELS") }
                    Button(onClick = {
                        scope.launch { prefs.saveProvider(baseUrl.trim(),key); prefs.saveTermuxPath(termuxPath.trim()); showSettings = false; status = "Provider saved with Keystore encryption." }
                    }) { Text("SAVE") }
                }
            })
    }
}
