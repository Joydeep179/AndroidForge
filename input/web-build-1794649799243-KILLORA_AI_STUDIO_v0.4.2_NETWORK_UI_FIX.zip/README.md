# KILLORA AI STUDIO v0.4.2

Android Kotlin + Jetpack Compose source project.

## v0.4.2 changes
- Retry transient DNS, connection and timeout failures up to four attempts with backoff.
- Show a clearer hostname/DNS error if the API host remains unreachable; chat history remains saved.
- Make API settings dialog scrollable and height-adaptive so model entries can be scrolled and selected on portrait and landscape screens.
- Respect status-bar, navigation-bar and keyboard insets; use adjustResize for landscape/keyboard layouts.
- Version bumped to 0.4.2 (versionCode 4).

Build with Android Studio or `gradle :app:assembleDebug` after installing the Android SDK.
